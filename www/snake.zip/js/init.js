require.config({
    baseUrl: 'js/lib'
});

requirejs(['../app']);
